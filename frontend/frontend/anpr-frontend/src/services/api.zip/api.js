const API_BASE_URL = "http://10.40.42.186:5000";

export const PREDICT_URL = `${API_BASE_URL}/predict`;

export async function predictVehicle(imageFile) {
  if (!imageFile) {
    throw new Error("Please select an image.");
  }

  const formData = new FormData();
  formData.append("image", imageFile);

  try {
    const response = await fetch(PREDICT_URL, {
      method: "POST",
      body: formData,
    });

    if (!response.ok) {
      throw new Error(
        `Backend returned HTTP ${response.status}`
      );
    }

    const result = await response.json();

    console.log("ANPR Backend Response:", result);

    return result;
  } catch (error) {
    console.error("ANPR Backend Error:", error);

    throw new Error(
      "Unable to connect to the ANPR backend. Make sure the Flask server is running and both devices are connected to the same network."
    );
  }
}