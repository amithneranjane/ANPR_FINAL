import { useState } from "react";
import { useNavigate, Link } from "react-router-dom";
import { predictVehicle } from "../services/api";

function LiveANPR() {
  const navigate = useNavigate();

  const [selectedFile, setSelectedFile] = useState(null);
  const [imagePreview, setImagePreview] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  // Handle image selection
  const handleImageSelect = (event) => {
    const file = event.target.files[0];

    if (!file) {
      return;
    }

    setSelectedFile(file);
    setImagePreview(URL.createObjectURL(file));
    setError("");
  };

  // Handle ANPR detection
  const handleDetect = async () => {
    if (!selectedFile) {
      setError("Please select a vehicle image first.");
      return;
    }

    setLoading(true);
    setError("");

    let result;

    // ------------------------------------------------
    // STEP 1: Try the real Flask backend
    // ------------------------------------------------
    try {
      result = await predictVehicle(selectedFile);

      console.log("Real ANPR Backend Response:", result);
    } catch (backendError) {
      console.warn(
        "Backend unavailable. Using temporary demo result.",
        backendError
      );

      // ------------------------------------------------
      // STEP 2: Temporary demo result
      // Used only because backend is currently unreachable
      // ------------------------------------------------
      result = {
        plate_number: "TN38AB1234",
        ocr_confidence: 92,
        plate_quality: "Good",
        status: "Recognized",
        alert: "No Alert",
        best_method: "OCR",
        detection_time: new Date().toLocaleString(),
        location: "Demo Location",
        previous_detections: 2,
        latitude: null,
        longitude: null,
        demo_mode: true,
      };
    }

    // ------------------------------------------------
    // STEP 3: Save detection to localStorage
    // ------------------------------------------------
    try {
      const existingHistory = JSON.parse(
        localStorage.getItem("anpr_detection_history") || "[]"
      );

      const newDetection = {
        id: Date.now(),

        plate_number: result.plate_number,

        ocr_confidence: result.ocr_confidence,

        plate_quality: result.plate_quality,

        status: result.status,

        alert: result.alert,

        best_method: result.best_method,

        detection_time: result.detection_time,

        location: result.location,

        previous_detections: result.previous_detections,

        latitude: result.latitude ?? result.lat ?? null,

        longitude: result.longitude ?? result.lng ?? null,

        demo_mode: result.demo_mode ?? false,
      };

      existingHistory.unshift(newDetection);

      localStorage.setItem(
        "anpr_detection_history",
        JSON.stringify(existingHistory)
      );

      console.log("Detection saved:", newDetection);

      // ------------------------------------------------
      // STEP 4: Open Recognition Result page
      // ------------------------------------------------
      navigate("/recognition-result", {
        state: {
          ...result,
          original_image: imagePreview,
        },
      });
    } catch (historyError) {
      console.error("Detection History Error:", historyError);

      setError("Unable to save the detection result.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div
      style={{
        minHeight: "100vh",
        background: "#0b132b",
        color: "white",
        paddingBottom: "40px",
      }}
    >
      {/* ============================= */}
      {/* NAVIGATION */}
      {/* ============================= */}

      <nav
        style={{
          display: "flex",
          gap: "35px",
          padding: "20px 35px",
          background: "#1c2942",
          flexWrap: "wrap",
        }}
      >
        <Link to="/dashboard" style={navStyle}>
          🏠 Dashboard
        </Link>

        <Link to="/vehicle-detection" style={navStyle}>
          🚗 Vehicle Detection
        </Link>

        <Link to="/vehicle-records" style={navStyle}>
          🔎 Detection History
        </Link>

        <Link to="/analytics" style={navStyle}>
          📊 Analytics
        </Link>

        <Link to="/watchlist" style={navStyle}>
          🚨 Watchlist
        </Link>

        <Link to="/location" style={navStyle}>
          🗺️ Map
        </Link>

        <Link to="/reports" style={navStyle}>
          📄 Reports
        </Link>
      </nav>

      {/* ============================= */}
      {/* PAGE TITLE */}
      {/* ============================= */}

      <div style={{ padding: "35px 40px 20px" }}>
        <h1
          style={{
            fontSize: "36px",
            marginBottom: "8px",
          }}
        >
          🚗 Live ANPR Detection
        </h1>

        <p
          style={{
            color: "#b8c2d9",
            fontSize: "17px",
          }}
        >
          Upload a vehicle image and run AI-powered number plate recognition.
        </p>
      </div>

      {/* ============================= */}
      {/* MAIN CONTENT */}
      {/* ============================= */}

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "1fr 1fr",
          gap: "30px",
          padding: "20px 40px",
        }}
      >
        {/* ============================= */}
        {/* IMAGE UPLOAD SECTION */}
        {/* ============================= */}

        <div
          style={{
            background: "#16213a",
            padding: "30px",
            borderRadius: "12px",
            border: "1px solid #2d3a55",
          }}
        >
          <h2
            style={{
              marginBottom: "20px",
            }}
          >
            📷 Vehicle Image
          </h2>

          {/* IMAGE PREVIEW */}

          <div
            style={{
              minHeight: "350px",
              border: "2px dashed #53627d",
              borderRadius: "10px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
              overflow: "hidden",
              background: "#101a30",
            }}
          >
            {imagePreview ? (
              <img
                src={imagePreview}
                alt="Selected vehicle"
                style={{
                  width: "100%",
                  maxHeight: "350px",
                  objectFit: "contain",
                }}
              />
            ) : (
              <div
                style={{
                  textAlign: "center",
                  color: "#9aa7bd",
                  padding: "30px",
                }}
              >
                <div
                  style={{
                    fontSize: "60px",
                  }}
                >
                  📷
                </div>

                <p>
                  Select a vehicle image to begin ANPR detection
                </p>
              </div>
            )}
          </div>

          {/* FILE INPUT */}

          <div
            style={{
              marginTop: "20px",
            }}
          >
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handleImageSelect}
              style={{
                width: "100%",
                padding: "12px",
                background: "#24314b",
                color: "white",
                borderRadius: "8px",
              }}
            />
          </div>

          {/* DETECT BUTTON */}

          <button
            onClick={handleDetect}
            disabled={loading}
            style={{
              width: "100%",
              marginTop: "20px",
              padding: "15px",
              border: "none",
              borderRadius: "8px",
              background: loading ? "#53627d" : "#2563eb",
              color: "white",
              fontSize: "17px",
              fontWeight: "bold",
              cursor: loading ? "not-allowed" : "pointer",
            }}
          >
            {loading
              ? "⏳ Processing..."
              : "🔍 Run ANPR Detection"}
          </button>

          {/* ERROR MESSAGE */}

          {error && (
            <div
              style={{
                marginTop: "20px",
                padding: "15px",
                borderRadius: "8px",
                background: "#4a1f2a",
                color: "#ffb4b4",
              }}
            >
              {error}
            </div>
          )}
        </div>

        {/* ============================= */}
        {/* ANPR INFORMATION SECTION */}
        {/* ============================= */}

        <div
          style={{
            background: "#16213a",
            padding: "30px",
            borderRadius: "12px",
            border: "1px solid #2d3a55",
          }}
        >
          <h2
            style={{
              marginBottom: "25px",
            }}
          >
            🤖 ANPR Process
          </h2>

          {/* STEP 1 */}

          <div style={stepStyle}>
            <span>1️⃣</span>

            <div>
              <strong>Upload Image</strong>

              <p style={descriptionStyle}>
                Select a vehicle image from your computer.
              </p>
            </div>
          </div>

          {/* STEP 2 */}

          <div style={stepStyle}>
            <span>2️⃣</span>

            <div>
              <strong>Vehicle Detection</strong>

              <p style={descriptionStyle}>
                YOLO detects the vehicle and number plate region.
              </p>
            </div>
          </div>

          {/* STEP 3 */}

          <div style={stepStyle}>
            <span>3️⃣</span>

            <div>
              <strong>OCR Recognition</strong>

              <p style={descriptionStyle}>
                OCR extracts the number plate characters.
              </p>
            </div>
          </div>

          {/* STEP 4 */}

          <div style={stepStyle}>
            <span>4️⃣</span>

            <div>
              <strong>Result</strong>

              <p style={descriptionStyle}>
                The recognition result is displayed with confidence,
                quality, status and alert information.
              </p>
            </div>
          </div>

          {/* BACKEND STATUS */}

          <div
            style={{
              marginTop: "25px",
              padding: "18px",
              background: "#101a30",
              borderRadius: "8px",
            }}
          >
            <strong>Backend Status</strong>

            <p
              style={{
                marginTop: "8px",
                color: "#facc15",
              }}
            >
              🟡 Backend connection will be tested when ANPR detection
              is executed.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

// =============================
// NAVIGATION STYLE
// =============================

const navStyle = {
  color: "white",
  textDecoration: "none",
  fontSize: "15px",
};

// =============================
// PROCESS STEP STYLE
// =============================

const stepStyle = {
  display: "flex",
  gap: "15px",
  padding: "18px",
  marginBottom: "12px",
  background: "#101a30",
  borderRadius: "8px",
  alignItems: "flex-start",
};

// =============================
// DESCRIPTION STYLE
// =============================

const descriptionStyle = {
  color: "#9aa7bd",
  marginTop: "6px",
  marginBottom: 0,
  lineHeight: "1.5",
};

export default LiveANPR;