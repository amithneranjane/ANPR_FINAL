import { Link, useLocation } from "react-router-dom";

function RecognitionResult() {
  const location = useLocation();
  const data = location.state || {};

  const plateNumber = data.plate_number || "--";
  const confidence = data.ocr_confidence ?? "--";
  const plateQuality = data.plate_quality || "--";
  const status = data.status || "--";
  const bestMethod = data.best_method || "--";
  const previousDetections = data.previous_detections ?? 0;
  const detectionTime = data.detection_time || "--";
  const detectionLocation = data.location || "--";
  const alert = data.alert || "None";

  const isAlert =
    alert &&
    String(alert).toLowerCase() !== "none";

  return (
    <div style={pageStyle}>
      <nav style={navStyle}>
        <Link to="/dashboard" style={linkStyle}>
          🏠 Dashboard
        </Link>

        <Link to="/vehicle-detection" style={linkStyle}>
          🚗 Vehicle Detection
        </Link>

        <Link to="/vehicle-records" style={linkStyle}>
          🔎 Detection History
        </Link>

        <Link to="/location" style={linkStyle}>
          🗺️ Map
        </Link>

        <Link to="/analytics" style={linkStyle}>
          📊 Analytics
        </Link>

        <Link to="/watchlist" style={linkStyle}>
          🚨 Watchlist
        </Link>

        <Link to="/reports" style={linkStyle}>
          📄 Reports
        </Link>
      </nav>

      <main style={mainStyle}>
        <h1>🔎 Number Plate Recognition Result</h1>

        <p style={subtitleStyle}>
          AI-powered number plate recognition details
        </p>

        {data.original_image && (
          <div style={cardStyle}>
            <h2>Vehicle Image</h2>

            <img
              src={data.original_image}
              alt="Detected vehicle"
              style={imageStyle}
            />
          </div>
        )}

        <div style={gridStyle}>
          <div style={cardStyle}>
            <h2>Number Plate</h2>

            <div style={plateStyle}>
              {plateNumber}
            </div>

            <p>
              <strong>OCR Confidence:</strong>{" "}
              {confidence}
              {confidence !== "--" ? "%" : ""}
            </p>

            <p>
              <strong>Plate Quality:</strong>{" "}
              {plateQuality}
            </p>

            <p>
              <strong>Status:</strong>{" "}
              {status}
            </p>
          </div>

          <div style={cardStyle}>
            <h2>Detection Information</h2>

            <p>
              <strong>Best OCR Method:</strong>{" "}
              {bestMethod}
            </p>

            <p>
              <strong>Previous Detections:</strong>{" "}
              {previousDetections}
            </p>

            <p>
              <strong>Detection Time:</strong>{" "}
              {detectionTime}
            </p>

            <p>
              <strong>Location:</strong>{" "}
              {detectionLocation}
            </p>
          </div>
        </div>

        <div
          style={{
            ...cardStyle,
            border: isAlert
              ? "2px solid #ef4444"
              : "2px solid #22c55e",
          }}
        >
          <h2>
            {isAlert
              ? "🚨 Alert"
              : "✅ Alert Status"}
          </h2>

          <p
            style={{
              fontSize: "18px",
              color: isAlert
                ? "#f87171"
                : "#4ade80",
            }}
          >
            {isAlert ? alert : "No Alert"}
          </p>
        </div>

        {(plateQuality === "Poor" ||
          plateQuality === "Very Poor") && (
          <div style={warningStyle}>
            ⚠️ Low-resolution plate — Manual
            verification recommended.
          </div>
        )}

        {previousDetections > 0 && (
          <div style={infoStyle}>
            🔁 This vehicle has been detected{" "}
            {previousDetections} previous time(s).
          </div>
        )}

        <div style={buttonContainerStyle}>
          <Link
            to="/vehicle-details"
            state={data}
            style={buttonStyle}
          >
            🚗 Vehicle Details
          </Link>

          <Link
            to="/vehicle-records"
            style={buttonStyle}
          >
            📋 Detection History
          </Link>

          <Link
            to="/dashboard"
            style={buttonStyle}
          >
            🏠 Back to Dashboard
          </Link>
        </div>
      </main>
    </div>
  );
}

const pageStyle = {
  minHeight: "100vh",
  background: "#0b132b",
  color: "white",
};

const navStyle = {
  display: "flex",
  gap: "30px",
  padding: "20px 35px",
  background: "#1c2942",
  flexWrap: "wrap",
};

const linkStyle = {
  color: "white",
  textDecoration: "none",
};

const mainStyle = {
  padding: "35px 40px",
};

const subtitleStyle = {
  color: "#9aa7bd",
  marginBottom: "30px",
};

const gridStyle = {
  display: "grid",
  gridTemplateColumns:
    "repeat(auto-fit, minmax(300px, 1fr))",
  gap: "25px",
};

const cardStyle = {
  background: "#16213a",
  padding: "25px",
  borderRadius: "12px",
  marginBottom: "25px",
};

const plateStyle = {
  background: "#f5f5f5",
  color: "#111",
  padding: "18px",
  borderRadius: "8px",
  fontSize: "30px",
  fontWeight: "bold",
  textAlign: "center",
  margin: "20px 0",
};

const imageStyle = {
  width: "100%",
  maxWidth: "600px",
  maxHeight: "400px",
  objectFit: "contain",
  display: "block",
  margin: "20px auto",
  borderRadius: "10px",
};

const warningStyle = {
  background: "#4a3515",
  color: "#facc15",
  padding: "18px",
  borderRadius: "8px",
  marginBottom: "20px",
};

const infoStyle = {
  background: "#172f46",
  color: "#60a5fa",
  padding: "18px",
  borderRadius: "8px",
  marginBottom: "20px",
};

const buttonContainerStyle = {
  display: "flex",
  gap: "15px",
  flexWrap: "wrap",
};

const buttonStyle = {
  background: "#2563eb",
  color: "white",
  textDecoration: "none",
  padding: "12px 18px",
  borderRadius: "8px",
};

export default RecognitionResult;